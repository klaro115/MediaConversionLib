﻿using System;

namespace MediaCommons
{
	public enum MediaPixelFormat
	{
		Mono,			// A single channel per data point.

		ColorAlpha,     // 2-3 color channels, followed by alpha as an optional 4th channel, in byte-order. (Ex.: RGBA8888, BGR888, RGB565)
		AlphaColor,     // Leading alpha channel followed by 2-3 color channels, in byte-order. (Ex.: ARGB, ABGR)

		YUV,			// Any one out of a number of supported common YUV formats with subsampled color channels.

		Other,			// A custom data structure or content type that does not necessarily represent pixel data.
	}

	/// <summary>
	/// Sub types for monochrome pixel formats. These sub types for single-value pixels only clear up the data type.
	/// </summary>
	public enum MediaSubType_Mono : int
	{
		Integer,		// 8, 16, 32, or 64-bits unsigned integer number per pixel.
		Float,			// 16-bit half, 32-bit single, or 64-bit double precision floating point number per pixel.

		Other,			// An custom structure per pixel.
	}

	/// <summary>
	/// A sub type describing the color channel layout of the color pixel formats '<see cref="MediaPixelFormat.ColorAlpha"/>' and
	/// '<see cref="MediaPixelFormat.AlphaColor"/>'.
	/// </summary>
	public enum MediaSubType_Color : int
	{
		RGB,			// Up to 3 color channels in Red-Green-Blue memory address order, can also be used for AYUV.
		BGR,            // Up to 3 color channels in Blue-Green-Red memory address order.

		Other,			// A custom or specialized color representation, possibly with more than 4 color channels per pixel.
	}

	/// <summary>
	/// Sub types for YUV pixel formats, specifying the YUV data layout that's being used.
	/// </summary>
	public enum MediaSubType_YUV : int
	{
		YUY2,			// 8-bit 4:2:2 sampled packed format. Each pixel contains a luminance (Y) value followed by alternating U/V components.
		UYVY,           // 8-bit 4:2:2 sampled packed format. Each pixel contains alternating U/V components followed by a luminance (Y) value.
		NV12,			// 8-bit 4:2:0 sampled planar format. The 1st plane contains luminance (Y) for each pixel, 2nd plane is alternating U/V values.

		Other,			// An uncommon or non-native YUV format.
	}

	/// <summary>
	/// Helper class extending the functionality of the pixel format and sub type enumerations.
	/// </summary>
	public static class MediaPixelFormatExt
	{
		#region Methods

		/// <summary>
		/// Check if the given sub type for this pixel format is planar. If the format isn't planar, it is assumed to be packed instead.
		/// </summary>
		/// <param name="_pixelFormat">This pixel format.</param>
		/// <param name="_subType">A sub type of this pixel format that you need to know if it's planar or not.</param>
		/// <returns>True if it is planar, false if the sub type is packed or unknown.</returns>
		public static bool IsPlanar(this MediaPixelFormat _pixelFormat, int _subType)
		{
			switch (_pixelFormat)
			{
				case MediaPixelFormat.YUV:
					{
						switch ((MediaSubType_YUV)_subType)
						{
							case MediaSubType_YUV.NV12:
								return true;
							default:
								break;
						}
					}
					break;
				default:
					break;
			}
			return false;
		}

		public static string ToString(this MediaPixelFormat _pixelFormat, int _subType)
		{
			switch (_pixelFormat)
			{
				case MediaPixelFormat.Mono:
					{
						MediaSubType_Mono subTypeMono = (MediaSubType_Mono)_subType;
						return $"Mono {subTypeMono}";
					}
				case MediaPixelFormat.ColorAlpha:
					{
						MediaSubType_Color subTypeColor = (MediaSubType_Color)_subType;
						switch (subTypeColor)
						{
							case MediaSubType_Color.RGB:
								return "RGBA";
							case MediaSubType_Color.BGR:
								return "BGRA";
							default:
								return "Misc. Color";
						}
					}
				case MediaPixelFormat.AlphaColor:
					{
						MediaSubType_Color subTypeColor = (MediaSubType_Color)_subType;
						switch (subTypeColor)
						{
							case MediaSubType_Color.RGB:
								return "ARGB";
							case MediaSubType_Color.BGR:
								return "ABGR";
							default:
								return "Misc. Alpha+Color";
						}
					}
				case MediaPixelFormat.YUV:
					{
						MediaSubType_YUV subTypeYuv = (MediaSubType_YUV)_subType;
						switch (subTypeYuv)
						{
							case MediaSubType_YUV.YUY2:
							case MediaSubType_YUV.UYVY:
							case MediaSubType_YUV.NV12:
								return subTypeYuv.ToString();
							default:
								return "Misc. YUV";
						}
					}
				default:
					return "Misc. Format";
			}
		}

		#endregion
	}
}
