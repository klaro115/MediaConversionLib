﻿using System;

namespace MediaCommons.Media
{
	public abstract class MediaSample
	{
		#region Constructors

		protected MediaSample(MediaSampleFormat _format, MediaSampleDescription _description, int _maxSize)
		{
			format = _format;
			description = _description ?? MediaSampleDescription.Default;

			maxSize = Math.Max(_maxSize, 1);
			size = maxSize;
		}

		#endregion
		#region Fields

		public readonly MediaSampleFormat format = null;
		public readonly MediaSampleDescription description = null;

		public readonly int maxSize = 0;
		public int size = 0;

		#endregion
		#region Properties

		public abstract object Sample { get; }

		#endregion
		#region Methods

		public abstract void Clear();

		#endregion
	}

	public class MediaSample<T> : MediaSample
	{
		#region Constructors

		public MediaSample(MediaSampleFormat _format, MediaSampleDescription _description, int _maxSize) : base(_format, _description, _maxSize)
		{
			//...
		}

		#endregion
		#region Fields

		public T sample = default(T);

		#endregion
		#region Properties

		public override object Sample => sample;

		#endregion
		#region Methods

		public override void Clear()
		{
			sample = default(T);
			size = 0;
		}

		#endregion
	}
}
