﻿using System;

namespace MediaCommons
{
	[Serializable]
	public class MediaSampleDescription
	{
		#region Constructors

		public MediaSampleDescription(int _sampleCount, int _width, int _height, int _depth = 1)
		{
			sampleCount = Math.Max(_sampleCount, 1);

			width = Math.Max(_width, 1);
			heigth = Math.Max(_height, 1);
			depth = Math.Max(_depth, 1);
		}

		public MediaSampleDescription(int _sampleCount, int _width, int _height, int _depth, int _strideX, int _strideY, int _strideZ = 0) : this(_sampleCount, _width, _height, _depth)
		{
			strideX = Math.Max(_strideX, 0);
			strideY = Math.Max(_strideY, 0);
			strideZ = Math.Max(_strideZ, 0);
		}

		#endregion
		#region Fields

		public readonly int sampleCount = 1;

		public readonly int width = 640;
		public readonly int heigth = 480;
		public readonly int depth = 1;

		public readonly int strideX = 0;
		public readonly int strideY = 0;
		public readonly int strideZ = 0;

		public float targetSampleRate = 30.0f;

		#endregion
		#region Properties

		public int PixelCount => width * heigth * depth;
		public int PaddedPixelCount => (width + strideX) * (heigth + strideY) * (depth + strideZ);

		public int PaddedWidth => width + strideX;
		public int PaddedHeight => heigth + strideY;
		public int PaddedDepth => depth + strideZ;

		public int Dimensions => depth < 2 ? (heigth < 2 ? 1 : 2) : 3;

		public static MediaSampleDescription Default => new MediaSampleDescription(1, 640, 480, 1, 0, 0, 0) { targetSampleRate = 30.0f };

		#endregion
	}
}
