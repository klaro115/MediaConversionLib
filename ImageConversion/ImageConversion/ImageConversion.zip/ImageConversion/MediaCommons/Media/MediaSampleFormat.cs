﻿using System;

namespace MediaCommons
{
	[Serializable]
	public class MediaSampleFormat
	{
		#region Constructors

		public MediaSampleFormat(int _bufferLocation, MediaPixelFormat _pixelFormat, int _subType, int _channelCount, int _maxBytesPerPixel, int _maxBitsPerChannel)
		{
			bufferLocation = _bufferLocation;
			pixelFormat = _pixelFormat;
			subType = _subType;
			isPlanar = pixelFormat.IsPlanar(_subType);

			channelCount = Math.Max(_channelCount, 1);
			maxBytesPerPixel = Math.Max(_maxBytesPerPixel, 1);
			maxBitsPerChannel = Math.Max(_maxBitsPerChannel, 3);
		}

		#endregion
		#region Fields

		public readonly int bufferLocation = 0;
		public readonly MediaPixelFormat pixelFormat = MediaPixelFormat.Mono;
		public readonly int subType = (int)MediaSubType_Mono.Integer;
		public readonly bool isPlanar = false;

		public readonly int channelCount = 1;
		public readonly int maxBytesPerPixel = 1;
		public readonly int maxBitsPerChannel = 8;

		#endregion
		#region Formats

		// Common mono formats:
		public static readonly MediaSampleFormat UInt8 = new MediaSampleFormat(0, MediaPixelFormat.Mono, (int)MediaSubType_Mono.Integer, 1, 1, 8);			// Y8
		public static readonly MediaSampleFormat UInt16 = new MediaSampleFormat(0, MediaPixelFormat.Mono, (int)MediaSubType_Mono.Integer, 1, 2, 16);		// Y16
		public static readonly MediaSampleFormat UInt32 = new MediaSampleFormat(0, MediaPixelFormat.Mono, (int)MediaSubType_Mono.Integer, 1, 4, 32);		// Y32
		public static readonly MediaSampleFormat UInt64 = new MediaSampleFormat(0, MediaPixelFormat.Mono, (int)MediaSubType_Mono.Integer, 1, 8, 64);		// Y64
		public static readonly MediaSampleFormat Float32 = new MediaSampleFormat(0, MediaPixelFormat.Mono, (int)MediaSubType_Mono.Float, 1, 4, 32);			// Y32_Float
		public static readonly MediaSampleFormat Float64 = new MediaSampleFormat(0, MediaPixelFormat.Mono, (int)MediaSubType_Mono.Float, 1, 8, 64);			// Y64_Double

		// Common RGBA / ARGB formats:
		public static readonly MediaSampleFormat ARGB32 = new MediaSampleFormat(0, MediaPixelFormat.AlphaColor, (int)MediaSubType_Color.RGB, 4, 4, 8);		// A8_R8_G8_B8
		public static readonly MediaSampleFormat RGBA32 = new MediaSampleFormat(0, MediaPixelFormat.ColorAlpha, (int)MediaSubType_Color.RGB, 4, 4, 8);		// R8_G8_B8_A8
		public static readonly MediaSampleFormat RGBA64 = new MediaSampleFormat(0, MediaPixelFormat.ColorAlpha, (int)MediaSubType_Color.RGB, 4, 8, 16);		// R16_G16_B16_A16

		// Common BGRA / ABGR formats:
		public static readonly MediaSampleFormat ABGR32 = new MediaSampleFormat(0, MediaPixelFormat.AlphaColor, (int)MediaSubType_Color.BGR, 4, 4, 8);		// A8_B8_G8_R8
		public static readonly MediaSampleFormat BGRA32 = new MediaSampleFormat(0, MediaPixelFormat.ColorAlpha, (int)MediaSubType_Color.BGR, 4, 4, 8);		// B8_G8_R8_A8
		public static readonly MediaSampleFormat BGRA64 = new MediaSampleFormat(0, MediaPixelFormat.ColorAlpha, (int)MediaSubType_Color.BGR, 4, 8, 16);		// B16_G16_R16_A16

		// Common YUV formats:
		public static readonly MediaSampleFormat YUY2 = new MediaSampleFormat(0, MediaPixelFormat.YUV, (int)MediaSubType_YUV.YUY2, 3, 2, 8);				// 4:2:2, Y8_U8 / Y8_V8
		public static readonly MediaSampleFormat NV12 = new MediaSampleFormat(0, MediaPixelFormat.YUV, (int)MediaSubType_YUV.NV12, 3, 2, 8);                // 4:2:0, Y8 + U8_V8

		#endregion
		#region Methods

		public bool CompareIgnoreLocation(MediaSampleFormat _other)
		{
			if (_other == null) return false;
			if (_other == this) return true;

			return pixelFormat == _other.pixelFormat &&
				   subType == _other.subType &&
				   channelCount == _other.channelCount &&
				   maxBytesPerPixel == _other.maxBytesPerPixel &&
				   maxBitsPerChannel == _other.maxBitsPerChannel;
		}

		public bool Compare(MediaSampleFormat _other)
		{
			if (_other == null) return false;
			if (_other == this) return true;

			return CompareIgnoreLocation(_other) && bufferLocation == _other.bufferLocation;
		}

		public int CalculateMaximumSampleSize(int _paddedWidth, int _paddedHeight, int _paddedDepth = 1)
		{
			return Math.Max(_paddedDepth, 1) * Math.Max(_paddedHeight, 1) * Math.Max(_paddedWidth, 1) * maxBytesPerPixel;
		}

		public int CalculateMaximumSampleSize(MediaSampleDescription _sampleDescription)
		{
			return CalculateMaximumSampleSize(_sampleDescription.PaddedWidth, _sampleDescription.PaddedHeight, _sampleDescription.PaddedDepth);
		}

		public override string ToString()
		{
			return $"{pixelFormat.ToString(subType)}{maxBytesPerPixel * 8}";
		}

		#endregion
	}
}
