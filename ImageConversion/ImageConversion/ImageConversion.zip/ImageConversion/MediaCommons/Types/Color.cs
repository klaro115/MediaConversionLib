﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace MediaCommons.Types
{
	[Serializable]
	[StructLayout(LayoutKind.Sequential)]
	public struct Color
	{
		#region Constructors

		public Color(int _mono)
		{
			r = _mono;
			g = _mono;
			b = _mono;
			a = _mono;
		}

		public Color(int _red, int _green, int _blue, int _alpha = 255)
		{
			r = _red;
			g = _green;
			b = _blue;
			a = _alpha;
		}

		#endregion
		#region Fields

		public int r;
		public int g;
		public int b;
		public int a;

		#endregion
		#region Properties

		// Packed Color+Alpha:
		public uint Packed_R8G8B8A8 => PackColor_32(r, g, b, a);  // Note: These are all little-endian byte-order representations!
		public uint Packed_B8G8R8A8 => PackColor_32(b, g, r, a);

		// Packed Alpha+Color:
		public uint Packed_A8R8G8B8 => PackColor_32(a, r, g, b);
		public uint Packed_A8B8G8R8 => PackColor_32(a, b, g, r);

		#endregion
		#region Methods Packing

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public static uint PackColor_32(int byte0, int byte1, int byte2, int byte3)
		{
			return ((uint)byte3 << 24) | ((uint)byte2 << 16) | ((uint)byte1 << 8) | (uint)byte0;
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public static void UnpackColor_32(uint _packed, out int _outByte0, out int _outByte1, out int _outByte2, out int _outByte3)
		{
			_outByte0 = (int)_packed & 0xFF;
			_outByte1 = (int)(_packed >> 8) & 0xFF;
			_outByte2 = (int)(_packed >> 16) & 0xFF;
			_outByte3 = (int)(_packed >> 24) & 0xFF;
		}

		// RGBA 8888
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public static Color CreateFromPacked_R8G8B8A8(uint _packed)
		{
			Color color = new Color();
			UnpackColor_32(_packed, out color.r, out color.g, out color.b, out color.a);
			return color;
		}

		// BGRA 8888
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public static Color CreateFromPacked_B8G8R8A8(uint _packed)
		{
			Color color = new Color();
			UnpackColor_32(_packed, out color.b, out color.g, out color.r, out color.a);
			return color;
		}

		// ARGB
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public static Color CreateFromPacked_A8R8G8B8(uint _packed)
		{
			Color color = new Color();
			UnpackColor_32(_packed, out color.a, out color.r, out color.g, out color.b);
			return color;
		}

		// ABGR
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public static Color CreateFromPacked_A8B8G8R8(uint _packed)
		{
			Color color = new Color();
			UnpackColor_32(_packed, out color.a, out color.b, out color.g, out color.r);
			return color;
		}

		#endregion
	}
}
